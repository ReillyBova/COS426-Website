export { default as SeedScene } from './SeedScene.js';
