Source unknown:
"404.png" - source of sad cat image unknown
"maze.png" (originally "circuit_pattern.png")

The following textures from http://subtlepatterns.com/
"blocky.png" (originally "bright_squares256.png")
"cork.png"   (originally "cork-board.png")
"fabric.png" (originally "fabric_of_squares_gray.png")


Slightly modified to have more GPU friendly sizes.

Licensed under a Creative Commons Attribution 3.0 Unported License:
http://creativecommons.org/licenses/by/3.0/
